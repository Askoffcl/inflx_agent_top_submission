from agent.intent import detect_intent
from agent.rag import get_answer
from agent.memory import Memory
from agent.tools import mock_lead_capture

memory = Memory()
collecting = False

def run_agent(user_input):
    global collecting

    if not collecting:
        intent = detect_intent(user_input)

        if intent == "greeting":
            return "Hi! How can I help you with AutoStream?"

        if intent in ["pricing", "general"]:
            return get_answer(user_input)

        if intent == "high_intent":
            collecting = True
            return "Great! What's your name?"

    if collecting:
        if memory.name is None:
            memory.name = user_input
            return "Please provide your email."

        elif memory.email is None:
            memory.email = user_input
            return "Which platform do you create content on?"
        elif memory.platform is None:
            valid_platforms = ["youtube", "instagram", "tiktok"]

            if user_input.lower() not in valid_platforms:
                return "Please enter a valid platform (YouTube, Instagram, TikTok)."

            memory.platform = user_input

            if memory.is_complete():
                mock_lead_capture(memory.name, memory.email, memory.platform)

                # reset memory
                memory.name = None
                memory.email = None
                memory.platform = None

                collecting = False
                return "You're all set! We'll reach out soon."
    return "Let me know how I can help!"
