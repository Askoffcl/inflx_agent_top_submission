def detect_intent(text):
    t = text.lower()

    # HIGH INTENT FIRST (important)
    if any(x in t for x in ["buy", "subscribe", "try", "want", "start"]):
        return "high_intent"

    if any(x in t for x in ["hi", "hello"]):
        return "greeting"

    if any(x in t for x in ["price", "plan", "cost"]):
        return "pricing"

    return "general"