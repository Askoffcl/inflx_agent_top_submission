import json

with open("data/knowledge.json") as f:
    KB = json.load(f)

def get_answer(query):
    q = query.lower()
    if "price" in q or "plan" in q:
        return f"Basic: {KB['pricing']['basic']}\nPro: {KB['pricing']['pro']}"
    if "refund" in q:
        return KB["policies"]["refund"]
    return "I can help with pricing, plans, or policies."
