# Social-to-Lead Agentic Workflow (Inflx - AutoStream)

## Overview
A stateful GenAI agent that converts conversations into qualified leads using:
- Intent detection
- RAG over local knowledge base
- Tool execution (lead capture)
- Memory across multi-turn dialogue

## Setup
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Create `.env`:
```
OPENAI_API_KEY=your_key_here
```

## Run
```bash
python main.py
```

## Example Flow
- User asks pricing → agent answers from KB (RAG)
- User shows intent → agent collects name/email/platform
- Agent triggers mock_lead_capture

## Architecture (≈200 words)
This project uses LangChain to compose a modular agent with clear separation of concerns. 
The RAG pipeline loads a local JSON knowledge base and converts it into embeddings stored 
in FAISS for fast semantic retrieval. Queries are embedded and matched against the vector 
store to return relevant context, which is then passed to the LLM for grounded responses. 
Intent detection is implemented using a lightweight LLM classifier to better generalize 
beyond keyword matching. State is managed via a custom memory object that persists across 
turns, tracking collected lead attributes (name, email, platform). The agent follows a 
deterministic workflow: detect intent → answer via RAG → if high intent, enter a slot-filling 
loop → call tool only when all fields are collected. This hybrid design balances reliability 
(rule-based flow) with flexibility (LLM understanding).

## WhatsApp Integration (Webhooks)
To deploy on WhatsApp (e.g., via Meta Cloud API or Twilio), expose a webhook endpoint (FastAPI/Flask).
Incoming messages trigger the agent function, and responses are sent back via the provider API.
Maintain user sessions using sender IDs to map to memory state (e.g., Redis). Ensure idempotency 
and handle retries. Secure the webhook with verification tokens and HTTPS.

## Notes
- Uses GPT via OpenAI for intent + generation
- FAISS for local vector retrieval
- Simple CLI loop for demo
