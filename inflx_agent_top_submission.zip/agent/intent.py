from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

def detect_intent(text: str) -> str:
    prompt = f"""Classify intent into one of:
    greeting, pricing, high_intent, general

    Text: {text}
    Answer only the label."""

    res = llm.invoke(prompt).content.strip().lower()
    return res
