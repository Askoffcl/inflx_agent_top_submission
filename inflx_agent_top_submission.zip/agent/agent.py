from agent.intent import detect_intent
from agent.rag import get_answer
from agent.memory import Memory
from agent.tools import mock_lead_capture

memory = Memory()
collecting = False

def run_agent(user_input: str) -> str:
    global collecting

    if not collecting:
        intent = detect_intent(user_input)

        if intent == "greeting":
            return "Hi! Ask me anything about AutoStream."

        if intent in ["pricing", "general"]:
            return get_answer(user_input)

        if intent == "high_intent":
            collecting = True
            return "Great! What's your name?"

    # Slot filling
    if collecting:
        if memory.name is None:
            memory.name = user_input
            return "Your email?"

        elif memory.email is None:
            memory.email = user_input
            return "Which platform (YouTube/Instagram/etc.)?"

        elif memory.platform is None:
            memory.platform = user_input

            if memory.is_complete():
                mock_lead_capture(memory.name, memory.email, memory.platform)
                collecting = False
                return "You're registered! We'll contact you soon."

    return "How can I help?"
