import json
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.vectorstores import FAISS

embeddings = OpenAIEmbeddings()
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

def load_vectorstore():
    with open("data/knowledge.json") as f:
        data = json.load(f)["docs"]
    return FAISS.from_texts(data, embeddings)

vectordb = load_vectorstore()

def get_answer(query: str) -> str:
    docs = vectordb.similarity_search(query, k=2)
    context = "\n".join([d.page_content for d in docs])
    prompt = f"""Answer using context:
    {context}

    Question: {query}"""
    return llm.invoke(prompt).content
